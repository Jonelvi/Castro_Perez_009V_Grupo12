package Castro_Paris_009V_Grupo12.SinMemoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SinMemoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
