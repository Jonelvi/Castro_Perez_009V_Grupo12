package Castro_Paris_009V_Grupo12.SinMemoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinMemoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SinMemoriaApplication.class, args);
	}

}
