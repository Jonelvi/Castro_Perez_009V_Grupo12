package com.example.checkin_service.service;

import com.example.checkin_service.client.ReservaClient;
import com.example.checkin_service.dto.request.CheckinRequest;
import com.example.checkin_service.dto.response.CheckinResponse;
import com.example.checkin_service.exceptions.NotFoundException;
import com.example.checkin_service.model.Checkin;
import com.example.checkin_service.repository.CheckinRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

// Gestiona el proceso de entrada y salida del hotel (check-in / check-out)
// Se comunica con reservation-service para verificar y actualizar el estado de las reservas
@Service
@RequiredArgsConstructor
public class CheckinService {

    private final CheckinRepository checkinRepository;
    private final ReservaClient reservaClient; // llama a reservation-service

    // Realiza el check-in: registra la entrada del huésped
    // También actualiza el estado de la reserva a CONFIRMADA
    public CheckinResponse realizarCheckin(CheckinRequest req) {
        // Verifica que la reserva existe antes de hacer check-in
        reservaClient.obtenerReserva(req.getIdReserva());

        Checkin c = Checkin.builder()
                .idReserva(req.getIdReserva())
                .fechaCheckin(LocalDateTime.now()) // registra la hora exacta de entrada
                .idEmpleado(req.getIdEmpleado())
                .observaciones(req.getObservaciones())
                .build();

        // Cambia el estado de la reserva a CONFIRMADA en reservation-service
        // Esto es comunicación entre microservicios via OpenFeign
        reservaClient.cambiarEstado(req.getIdReserva(), "CONFIRMADA");

        return toResponse(checkinRepository.save(c), null);
    }

    // Realiza el check-out: registra la salida del huésped
    // Cambia el estado del checkin a COMPLETADO y la reserva a COMPLETADA
    public CheckinResponse realizarCheckout(Long id) {
        Checkin c = checkinRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Checkin no encontrado con id: " + id));

        c.setFechaCheckout(LocalDateTime.now()); // registra la hora de salida
        c.setEstado(Checkin.Estado.COMPLETADO);

        // Actualiza la reserva a COMPLETADA en reservation-service
        reservaClient.cambiarEstado(c.getIdReserva(), "COMPLETADA");

        return toResponse(checkinRepository.save(c), null);
    }

    public List<CheckinResponse> listar() {
        return checkinRepository.findAll().stream().map(c -> toResponse(c, null)).toList();
    }

    // Busca un checkin por ID incluyendo datos de la reserva
    public CheckinResponse buscarPorId(Long id) {
        Checkin c = checkinRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Checkin no encontrado con id: " + id));
        Map<String,Object> reserva = reservaClient.obtenerReserva(c.getIdReserva());
        return toResponse(c, reserva);
    }

    public List<CheckinResponse> listarPorReserva(Long idReserva) {
        return checkinRepository.findByIdReserva(idReserva).stream()
                .map(c -> toResponse(c, null)).toList();
    }

    private CheckinResponse toResponse(Checkin c, Map<String,Object> reserva) {
        return CheckinResponse.builder()
                .id(c.getId()).idReserva(c.getIdReserva()).reserva(reserva)
                .fechaCheckin(c.getFechaCheckin()).fechaCheckout(c.getFechaCheckout())
                .estado(c.getEstado() != null ? c.getEstado().name() : null)
                .idEmpleado(c.getIdEmpleado()).observaciones(c.getObservaciones())
                .build();
    }
}
