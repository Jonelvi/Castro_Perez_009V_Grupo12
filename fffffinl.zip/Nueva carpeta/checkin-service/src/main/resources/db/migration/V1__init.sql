
CREATE TABLE IF NOT EXISTS checkins (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_reserva BIGINT NOT NULL,
    fecha_checkin DATETIME,
    fecha_checkout DATETIME,
    estado ENUM('ACTIVO','COMPLETADO','CANCELADO') DEFAULT 'ACTIVO',
    id_empleado BIGINT,
    observaciones TEXT
);
