package com.example.reservation_service.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

// Entidad central del sistema: representa una reserva de habitación
// Conecta usuario + habitación con fechas y precio
@Entity
@Table(name = "reservas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // IDs de otros microservicios (no son @ManyToOne porque están en BDs distintas)
    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "id_habitacion", nullable = false)
    private Long idHabitacion;

    // LocalDate almacena solo fecha sin hora (ej: 2025-12-25)
    @Column(name = "fecha_inicio", nullable = false)
    private LocalDate fechaInicio;

    @Column(name = "fecha_fin", nullable = false)
    private LocalDate fechaFin;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    // Precio calculado automáticamente: precio_noche × cantidad de días
    @Column(name = "precio_total")
    private Double precioTotal;

    private String notas;

    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;

    @PrePersist
    public void prePersist() {
        fechaCreacion = LocalDateTime.now();
        if (estado == null) estado = Estado.PENDIENTE;
    }

    public enum Estado { PENDIENTE, CONFIRMADA, CANCELADA, COMPLETADA }
}
