package com.example.room_service.service;

import com.example.room_service.client.HotelClient;
import com.example.room_service.dto.request.HabitacionRequest;
import com.example.room_service.dto.response.HabitacionResponse;
import com.example.room_service.exceptions.NotFoundException;
import com.example.room_service.model.Habitacion;
import com.example.room_service.repository.HabitacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

// Lógica de negocio para habitaciones
// Se comunica con hotel-service via HotelClient (OpenFeign)
@Service
@RequiredArgsConstructor
public class HabitacionService {

    private final HabitacionRepository habitacionRepository;
    private final HotelClient hotelClient; // cliente Feign para llamar a hotel-service

    // Crea una habitación verificando primero que el hotel existe
    public HabitacionResponse crear(HabitacionRequest req) {
        // Verifica que el hotel existe llamando a hotel-service
        // Si no existe, hotel-service lanza 404 y Feign lo propaga aquí
        hotelClient.obtenerHotelPorId(req.getIdHotel());

        Habitacion h = Habitacion.builder()
                .idHotel(req.getIdHotel())
                .numero(req.getNumero())
                .tipo(req.getTipo() != null ? Habitacion.Tipo.valueOf(req.getTipo()) : Habitacion.Tipo.SIMPLE)
                .precioNoche(req.getPrecioNoche())
                .capacidad(req.getCapacidad())
                .descripcion(req.getDescripcion())
                .build();
        return toResponse(habitacionRepository.save(h), null);
    }

    // Lista todas las habitaciones (sin datos del hotel para no hacer N llamadas a hotel-service)
    public List<HabitacionResponse> listar() {
        return habitacionRepository.findAll().stream().map(h -> toResponse(h, null)).toList();
    }

    // Busca por ID e incluye datos del hotel llamando a hotel-service
    public HabitacionResponse buscarPorId(Long id) {
        Habitacion h = habitacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Habitación no encontrada con id: " + id));
        // Llama a hotel-service para traer los datos del hotel asociado
        Map<String,Object> hotel = hotelClient.obtenerHotelPorId(h.getIdHotel());
        return toResponse(h, hotel);
    }

    // Filtra habitaciones por hotel (útil para ver todas las habitaciones de un hotel)
    public List<HabitacionResponse> listarPorHotel(Long idHotel) {
        return habitacionRepository.findByIdHotel(idHotel).stream()
                .map(h -> toResponse(h, null)).toList();
    }

    // Actualiza los datos de una habitación
    public HabitacionResponse actualizar(Long id, HabitacionRequest req) {
        Habitacion h = habitacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Habitación no encontrada con id: " + id));
        h.setNumero(req.getNumero());
        h.setPrecioNoche(req.getPrecioNoche());
        h.setCapacidad(req.getCapacidad());
        h.setDescripcion(req.getDescripcion());
        if (req.getTipo() != null) h.setTipo(Habitacion.Tipo.valueOf(req.getTipo()));
        return toResponse(habitacionRepository.save(h), null);
    }

    public void eliminar(Long id) {
        if (!habitacionRepository.existsById(id))
            throw new NotFoundException("Habitación no encontrada con id: " + id);
        habitacionRepository.deleteById(id);
    }

    // Convierte entidad Habitacion → DTO HabitacionResponse
    // hotel puede ser null cuando no necesitamos incluir datos del hotel en la respuesta
    private HabitacionResponse toResponse(Habitacion h, Map<String,Object> hotel) {
        return HabitacionResponse.builder()
                .id(h.getId()).idHotel(h.getIdHotel()).hotel(hotel)
                .numero(h.getNumero())
                .tipo(h.getTipo() != null ? h.getTipo().name() : null)
                .precioNoche(h.getPrecioNoche())
                .estado(h.getEstado() != null ? h.getEstado().name() : null)
                .capacidad(h.getCapacidad()).descripcion(h.getDescripcion())
                .build();
    }
}
