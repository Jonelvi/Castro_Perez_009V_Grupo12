package com.example.room_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

// @FeignClient permite hacer llamadas HTTP a otro microservicio sin escribir código de HTTP
// name: nombre lógico del cliente
// url: URL del hotel-service tomada del application.properties
@FeignClient(name = "hotel-service", url = "${hotel-service.url}")
public interface HotelClient {

    // Llama a GET http://localhost:8082/api/v1/hoteles/{id}
    // Si el hotel no existe, hotel-service lanza 404 y Feign propaga el error
    @GetMapping("/api/v1/hoteles/{id}")
    Map<String, Object> obtenerHotelPorId(@PathVariable Long id);
}
