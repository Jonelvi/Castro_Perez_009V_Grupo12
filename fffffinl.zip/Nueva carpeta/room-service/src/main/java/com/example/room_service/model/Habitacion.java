package com.example.room_service.model;

import jakarta.persistence.*;
import lombok.*;

// Entidad que representa una habitación del hotel en la BD room_db
@Entity
@Table(name = "habitaciones")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Habitacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // id_hotel es una referencia al hotel al que pertenece esta habitación
    // No usamos @ManyToOne porque hotel está en otra base de datos (hotel_db)
    // La comunicación se hace via OpenFeign cuando se necesitan datos del hotel
    @Column(name = "id_hotel", nullable = false)
    private Long idHotel;

    @Column(nullable = false)
    private String numero; // número de habitación, ej: "101", "202A"

    @Enumerated(EnumType.STRING)
    private Tipo tipo; // tipo de habitación

    @Column(name = "precio_noche", nullable = false)
    private Double precioNoche;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    private Integer capacidad; // número máximo de personas

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    // Asigna estado DISPONIBLE por defecto al crear una habitación
    @PrePersist
    public void prePersist() {
        if (estado == null) estado = Estado.DISPONIBLE;
    }

    public enum Tipo { SIMPLE, DOBLE, SUITE, FAMILIAR }
    public enum Estado { DISPONIBLE, OCUPADA, MANTENIMIENTO }
}
