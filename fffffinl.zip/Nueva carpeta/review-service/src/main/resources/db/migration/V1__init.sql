CREATE TABLE IF NOT EXISTS resenas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_usuario BIGINT NOT NULL,
    id_habitacion BIGINT NOT NULL,
    id_reserva BIGINT NOT NULL,
    calificacion TINYINT NOT NULL,
    titulo VARCHAR(150),
    comentario TEXT,
    estado ENUM('PENDIENTE','APROBADA','RECHAZADA') DEFAULT 'APROBADA',
    fecha_creacion DATETIME
);
