package com.example.review_service.dto.response;

import lombok.*; import java.time.LocalDateTime; import java.util.Map;

@Data @Builder
public class ResenaResponse {
    private Long id;
    private Long idUsuario;
    private Map<String, Object> usuario;
    private Long idHabitacion;
    private Map<String, Object> habitacion;
    private Long idReserva;
    private Integer calificacion;
    private String titulo;
    private String comentario;
    private String estado;
    private LocalDateTime fechaCreacion;
}
