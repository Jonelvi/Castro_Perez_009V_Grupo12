package com.example.review_service.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "resenas")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Resena {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_usuario", nullable = false) private Long idUsuario;
    @Column(name = "id_habitacion", nullable = false) private Long idHabitacion;
    @Column(name = "id_reserva", nullable = false) private Long idReserva;

    @Column(nullable = false) private Integer calificacion;
    private String titulo;
    @Column(columnDefinition = "TEXT") private String comentario;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    @Column(name = "fecha_creacion") private LocalDateTime fechaCreacion;

    @PrePersist public void prePersist() {
        fechaCreacion = LocalDateTime.now();
        if (estado == null) estado = Estado.APROBADA;
    }

    public enum Estado { PENDIENTE, APROBADA, RECHAZADA }
}
