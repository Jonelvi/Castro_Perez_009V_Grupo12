package com.example.review_service.controller;

import com.example.review_service.dto.request.ResenaRequest;
import com.example.review_service.dto.response.ResenaResponse;
import com.example.review_service.service.ResenaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List; import java.util.Map;

@RestController
@RequestMapping("/api/v1/resenas")
@RequiredArgsConstructor
public class ResenaController {

    private final ResenaService resenaService;

    @PostMapping
    public ResponseEntity<ResenaResponse> crear(@Valid @RequestBody ResenaRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(resenaService.crear(req));
    }
    @GetMapping
    public ResponseEntity<List<ResenaResponse>> listar() { return ResponseEntity.ok(resenaService.listar()); }
    @GetMapping("/{id}")
    public ResponseEntity<ResenaResponse> buscar(@PathVariable Long id) { return ResponseEntity.ok(resenaService.buscarPorId(id)); }
    @GetMapping("/habitacion/{idHabitacion}")
    public ResponseEntity<List<ResenaResponse>> listarPorHabitacion(@PathVariable Long idHabitacion) { return ResponseEntity.ok(resenaService.listarPorHabitacion(idHabitacion)); }
    @GetMapping("/habitacion/{idHabitacion}/promedio")
    public ResponseEntity<Map<String,Object>> promedio(@PathVariable Long idHabitacion) { return ResponseEntity.ok(resenaService.promedioHabitacion(idHabitacion)); }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) { resenaService.eliminar(id); return ResponseEntity.noContent().build(); }
}
