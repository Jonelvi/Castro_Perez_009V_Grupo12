package com.example.review_service.repository;

import com.example.review_service.model.Resena;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ResenaRepository extends JpaRepository<Resena, Long> {
    List<Resena> findByIdHabitacion(Long idHabitacion);
    List<Resena> findByIdUsuario(Long idUsuario);
    @Query("SELECT AVG(r.calificacion) FROM Resena r WHERE r.idHabitacion = :idHabitacion")
    Double promedioCalificacionPorHabitacion(Long idHabitacion);
}
