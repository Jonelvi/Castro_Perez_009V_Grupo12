package com.example.review_service.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ResenaRequest {
    @NotNull private Long idUsuario;
    @NotNull private Long idHabitacion;
    @NotNull private Long idReserva;
    @NotNull @Min(1) @Max(5) private Integer calificacion;
    private String titulo;
    private String comentario;
}
