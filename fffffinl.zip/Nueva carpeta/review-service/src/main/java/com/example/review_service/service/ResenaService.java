package com.example.review_service.service;

import com.example.review_service.client.HabitacionClient;
import com.example.review_service.client.UsuarioClient;
import com.example.review_service.dto.request.ResenaRequest;
import com.example.review_service.dto.response.ResenaResponse;
import com.example.review_service.exceptions.NotFoundException;
import com.example.review_service.model.Resena;
import com.example.review_service.repository.ResenaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

// Gestiona las reseñas y calificaciones de habitaciones
// Se comunica con user-service y room-service para verificar que existen
@Service
@RequiredArgsConstructor
public class ResenaService {

    private final ResenaRepository resenaRepository;
    private final UsuarioClient usuarioClient;       // llama a user-service
    private final HabitacionClient habitacionClient; // llama a room-service

    // Crea una reseña verificando que el usuario y la habitación existen
    public ResenaResponse crear(ResenaRequest req) {
        // Verifica en user-service que el usuario existe
        usuarioClient.obtenerUsuario(req.getIdUsuario());
        // Verifica en room-service que la habitación existe
        habitacionClient.obtenerHabitacion(req.getIdHabitacion());

        Resena r = Resena.builder()
                .idUsuario(req.getIdUsuario())
                .idHabitacion(req.getIdHabitacion())
                .idReserva(req.getIdReserva())
                .calificacion(req.getCalificacion()) // valor entre 1 y 5
                .titulo(req.getTitulo())
                .comentario(req.getComentario())
                .build();

        return toResponse(resenaRepository.save(r), null, null);
    }

    public List<ResenaResponse> listar() {
        return resenaRepository.findAll().stream().map(r -> toResponse(r, null, null)).toList();
    }

    // Busca reseña por ID incluyendo datos del usuario y la habitación
    public ResenaResponse buscarPorId(Long id) {
        Resena r = resenaRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Reseña no encontrada con id: " + id));
        Map<String,Object> usuario = usuarioClient.obtenerUsuario(r.getIdUsuario());
        Map<String,Object> habitacion = habitacionClient.obtenerHabitacion(r.getIdHabitacion());
        return toResponse(r, usuario, habitacion);
    }

    // Lista todas las reseñas de una habitación específica
    public List<ResenaResponse> listarPorHabitacion(Long idHabitacion) {
        return resenaRepository.findByIdHabitacion(idHabitacion).stream()
                .map(r -> toResponse(r, null, null)).toList();
    }

    // Calcula el promedio de calificaciones de una habitación
    // Usa una query JPQL en el repository para calcular el AVG directamente en la BD
    public Map<String, Object> promedioHabitacion(Long idHabitacion) {
        Double promedio = resenaRepository.promedioCalificacionPorHabitacion(idHabitacion);
        long total = resenaRepository.findByIdHabitacion(idHabitacion).size();
        return Map.of(
                "idHabitacion", idHabitacion,
                "promedio", promedio != null ? promedio : 0.0,
                "totalResenas", total
        );
    }

    public void eliminar(Long id) {
        if (!resenaRepository.existsById(id))
            throw new NotFoundException("Reseña no encontrada con id: " + id);
        resenaRepository.deleteById(id);
    }

    private ResenaResponse toResponse(Resena r, Map<String,Object> usuario, Map<String,Object> habitacion) {
        return ResenaResponse.builder()
                .id(r.getId()).idUsuario(r.getIdUsuario()).usuario(usuario)
                .idHabitacion(r.getIdHabitacion()).habitacion(habitacion)
                .idReserva(r.getIdReserva()).calificacion(r.getCalificacion())
                .titulo(r.getTitulo()).comentario(r.getComentario())
                .estado(r.getEstado() != null ? r.getEstado().name() : null)
                .fechaCreacion(r.getFechaCreacion()).build();
    }
}
