package com.example.review_service.exceptions;
public class NotFoundException extends RuntimeException {
    public NotFoundException(String m) { super(m); }
}
