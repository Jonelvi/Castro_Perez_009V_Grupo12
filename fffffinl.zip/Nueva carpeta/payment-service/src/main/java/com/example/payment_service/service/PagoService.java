package com.example.payment_service.service;

import com.example.payment_service.client.ReservaClient;
import com.example.payment_service.dto.request.PagoRequest;
import com.example.payment_service.dto.response.PagoResponse;
import com.example.payment_service.exceptions.NotFoundException;
import com.example.payment_service.model.Pago;
import com.example.payment_service.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

// Gestiona los pagos de reservas
// Verifica que la reserva existe antes de registrar el pago
@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository pagoRepository;
    private final ReservaClient reservaClient; // llama a reservation-service

    // Registra un pago para una reserva
    // El pago se aprueba automáticamente (en producción real se conectaría a una pasarela de pagos)
    public PagoResponse crear(PagoRequest req) {
        // Verifica que la reserva existe en reservation-service
        reservaClient.obtenerReserva(req.getIdReserva());

        Pago p = Pago.builder()
                .idReserva(req.getIdReserva())
                .monto(req.getMonto())
                .metodoPago(Pago.MetodoPago.valueOf(req.getMetodoPago()))
                .estado(Pago.Estado.APROBADO) // en este sistema el pago se aprueba automáticamente
                .referencia(req.getReferencia())
                .build();

        return toResponse(pagoRepository.save(p), null);
    }

    public List<PagoResponse> listar() {
        return pagoRepository.findAll().stream().map(p -> toResponse(p, null)).toList();
    }

    // Busca pago por ID incluyendo datos de la reserva
    public PagoResponse buscarPorId(Long id) {
        Pago p = pagoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Pago no encontrado con id: " + id));
        Map<String,Object> reserva = reservaClient.obtenerReserva(p.getIdReserva());
        return toResponse(p, reserva);
    }

    // Lista todos los pagos de una reserva específica
    public List<PagoResponse> listarPorReserva(Long idReserva) {
        return pagoRepository.findByIdReserva(idReserva).stream()
                .map(p -> toResponse(p, null)).toList();
    }

    // Permite cambiar el estado de un pago (ej: APROBADO → REEMBOLSADO)
    public PagoResponse cambiarEstado(Long id, String estado) {
        Pago p = pagoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Pago no encontrado con id: " + id));
        p.setEstado(Pago.Estado.valueOf(estado));
        return toResponse(pagoRepository.save(p), null);
    }

    private PagoResponse toResponse(Pago p, Map<String,Object> reserva) {
        return PagoResponse.builder()
                .id(p.getId()).idReserva(p.getIdReserva()).reserva(reserva)
                .monto(p.getMonto())
                .metodoPago(p.getMetodoPago() != null ? p.getMetodoPago().name() : null)
                .estado(p.getEstado() != null ? p.getEstado().name() : null)
                .fechaPago(p.getFechaPago()).referencia(p.getReferencia())
                .build();
    }
}
