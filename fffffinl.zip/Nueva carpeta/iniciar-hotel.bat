@echo off
echo ========================================
echo   HOTEL MICROSERVICES - INICIANDO...
echo ========================================
echo.

REM Cambia esta ruta a donde tienes tu proyecto
set BASE=%~dp0

echo [1/10] Iniciando auth-service (puerto 8088)...
start "auth-service" cmd /k "cd /d %BASE%auth-service && mvnw.cmd spring-boot:run"
timeout /t 15 /nobreak >nul

echo [2/10] Iniciando user-service (puerto 8081)...
start "user-service" cmd /k "cd /d %BASE%user-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [3/10] Iniciando hotel-service (puerto 8082)...
start "hotel-service" cmd /k "cd /d %BASE%hotel-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [4/10] Iniciando room-service (puerto 8083)...
start "room-service" cmd /k "cd /d %BASE%room-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [5/10] Iniciando reservation-service (puerto 8084)...
start "reservation-service" cmd /k "cd /d %BASE%reservation-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [6/10] Iniciando checkin-service (puerto 8085)...
start "checkin-service" cmd /k "cd /d %BASE%checkin-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [7/10] Iniciando payment-service (puerto 8086)...
start "payment-service" cmd /k "cd /d %BASE%payment-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [8/10] Iniciando notification-service (puerto 8087)...
start "notification-service" cmd /k "cd /d %BASE%notification-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [9/10] Iniciando review-service (puerto 8089)...
start "review-service" cmd /k "cd /d %BASE%review-service && mvnw.cmd spring-boot:run"
timeout /t 10 /nobreak >nul

echo [10/10] Iniciando report-service (puerto 8090)...
start "report-service" cmd /k "cd /d %BASE%report-service && mvnw.cmd spring-boot:run"

echo.
echo ========================================
echo   Todos los servicios iniciados!
echo   Se abrieron 10 ventanas separadas.
echo   Espera unos segundos a que carguen.
echo ========================================
pause
