package com.example.auth_service.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

// Clase utilitaria para generar y validar tokens JWT (JSON Web Token)
// Un JWT es un token seguro que contiene información del usuario (email, rol)
// Se usa para autenticar peticiones sin consultar la BD en cada request
@Component
public class JwtUtil {

    // Lee el valor de jwt.secret desde application.properties
    @Value("${jwt.secret}")
    private String secret;

    // Tiempo de expiración del token en milisegundos (86400000 = 24 horas)
    @Value("${jwt.expiration}")
    private long expiration;

    // Genera la clave HMAC-SHA a partir del secreto configurado
    // HMAC-SHA256 firma el token para garantizar que no fue alterado
    private Key getKey() {
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    // Genera un nuevo token JWT con email y rol del usuario
    // El token tiene 3 partes: Header.Payload.Signature (separadas por puntos)
    public String generateToken(String email, String rol) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + expiration);

        return Jwts.builder()
                .subject(email)          // "sub": identifica al usuario
                .claim("rol", rol)       // dato extra: rol del usuario
                .issuedAt(now)           // "iat": cuándo fue emitido
                .expiration(exp)         // "exp": cuándo expira
                .signWith(getKey())      // firma el token con la clave secreta
                .compact();              // genera el string final
    }

    // Extrae el email del token (del campo "sub")
    public String getEmail(String token) {
        return Jwts.parser()
                .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getSubject();
    }

    // Valida que el token sea auténtico y no haya expirado
    // Retorna true si es válido, false si está expirado o fue alterado
    public boolean validateToken(String token) {
        try {
            Jwts.parser()
                    .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                    .build()
                    .parseSignedClaims(token);
            return true;
        } catch (Exception e) {
            return false; // token inválido, expirado o alterado
        }
    }

    // Obtiene la fecha de expiración del token como LocalDateTime
    public LocalDateTime getExpiration(String token) {
        Date exp = Jwts.parser()
                .verifyWith(Keys.hmacShaKeyFor(secret.getBytes()))
                .build()
                .parseSignedClaims(token)
                .getPayload()
                .getExpiration();
        return exp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
}
