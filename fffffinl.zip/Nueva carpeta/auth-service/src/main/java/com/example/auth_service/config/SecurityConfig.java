package com.example.auth_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

// Configuración de Spring Security para auth-service
// Define cómo se protegen los endpoints y cómo se cifran las contraseñas
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // BCryptPasswordEncoder cifra las contraseñas con el algoritmo BCrypt
    // BCrypt es un algoritmo seguro de hash que agrega "sal" aleatoria
    // Nunca se guarda la contraseña en texto plano en la BD
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Define que TODOS los endpoints de auth-service son públicos (no requieren token)
    // Esto es correcto porque auth-service es el que genera los tokens
    // Los otros servicios deberían validar el token antes de responder
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // deshabilita CSRF porque usamos JWT (stateless)
            .authorizeHttpRequests(auth -> auth.anyRequest().permitAll()); // todos los endpoints son públicos
        return http.build();
    }
}
