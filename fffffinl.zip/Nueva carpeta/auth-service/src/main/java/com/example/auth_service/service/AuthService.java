package com.example.auth_service.service;

import com.example.auth_service.dto.request.LoginRequest;
import com.example.auth_service.dto.request.RegisterRequest;
import com.example.auth_service.dto.response.AuthResponse;
import com.example.auth_service.exceptions.NotFoundException;
import com.example.auth_service.model.Usuario;
import com.example.auth_service.repository.UsuarioRepository;
import com.example.auth_service.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

// Servicio de autenticación: maneja registro, login y validación de tokens
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final JwtUtil jwtUtil;                // para generar/validar JWT
    private final PasswordEncoder passwordEncoder; // para cifrar contraseñas

    // Registra un nuevo usuario cifrando su contraseña antes de guardar
    public AuthResponse register(RegisterRequest req) {
        // Verifica que el email no esté ya registrado
        if (usuarioRepository.existsByEmail(req.getEmail()))
            throw new RuntimeException("El email ya está registrado");

        Usuario u = Usuario.builder()
                .nombre(req.getNombre())
                .email(req.getEmail())
                // passwordEncoder.encode() cifra la contraseña con BCrypt
                // NUNCA se guarda la contraseña en texto plano
                .password(passwordEncoder.encode(req.getPassword()))
                .rol(req.getRol() != null ? Usuario.Rol.valueOf(req.getRol()) : Usuario.Rol.CLIENTE)
                .build();

        usuarioRepository.save(u);

        // Genera el token JWT para que el usuario pueda usarlo inmediatamente
        String token = jwtUtil.generateToken(u.getEmail(), u.getRol().name());

        return AuthResponse.builder()
                .token(token)
                .tipo("Bearer") // tipo estándar de token HTTP
                .id(u.getId())
                .email(u.getEmail())
                .nombre(u.getNombre())
                .rol(u.getRol().name())
                .fechaExpiracion(jwtUtil.getExpiration(token))
                .build();
    }

    // Autentica un usuario verificando email y contraseña
    public AuthResponse login(LoginRequest req) {
        // Busca el usuario por email
        Usuario u = usuarioRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));

        // passwordEncoder.matches() compara la contraseña recibida con el hash guardado
        // Nunca se desencripta el hash, solo se verifica si coincide
        if (!passwordEncoder.matches(req.getPassword(), u.getPassword()))
            throw new RuntimeException("Contraseña incorrecta");

        String token = jwtUtil.generateToken(u.getEmail(), u.getRol().name());

        return AuthResponse.builder()
                .token(token).tipo("Bearer")
                .id(u.getId()).email(u.getEmail()).nombre(u.getNombre())
                .rol(u.getRol().name()).fechaExpiracion(jwtUtil.getExpiration(token))
                .build();
    }

    // Valida si un token JWT es válido (no expirado, no alterado)
    public boolean validateToken(String token) {
        return jwtUtil.validateToken(token);
    }
}
