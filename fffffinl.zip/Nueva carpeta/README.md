# Hotel Microservices - 10 servicios

## Puertos
| Servicio             | Puerto App | Puerto BD |
|----------------------|-----------|-----------|
| auth-service         | 8088      | 3314      |
| user-service         | 8081      | 3307      |
| hotel-service        | 8082      | 3308      |
| room-service         | 8083      | 3309      |
| reservation-service  | 8084      | 3310      |
| checkin-service      | 8085      | 3311      |
| payment-service      | 8086      | 3312      |
| notification-service | 8087      | 3313      |
| review-service       | 8089      | 3315      |
| report-service       | 8090      | 3316      |

## Inicio
1. `docker-compose up -d`
2. Levantar cada servicio con `./mvnw spring-boot:run`

## Endpoints
| Servicio             | Endpoints                                      |
|----------------------|------------------------------------------------|
| auth-service         | POST /api/v1/auth/register, /login, /validate  |
| user-service         | CRUD /api/v1/usuarios                          |
| hotel-service        | CRUD /api/v1/hoteles                           |
| room-service         | CRUD /api/v1/habitaciones                      |
| reservation-service  | CRUD /api/v1/reservas                          |
| checkin-service      | /api/v1/checkins, PATCH /{id}/checkout         |
| payment-service      | CRUD /api/v1/pagos                             |
| notification-service | /api/v1/notificaciones                         |
| review-service       | CRUD /api/v1/resenas, GET promedio             |
| report-service       | GET /api/v1/reportes/general, /reservas, etc.  |
