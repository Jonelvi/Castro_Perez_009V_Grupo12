package com.example.user_service.service;

import com.example.user_service.dto.request.UsuarioRequest;
import com.example.user_service.dto.response.UsuarioResponse;
import com.example.user_service.exceptions.NotFoundException;
import com.example.user_service.model.Usuario;
import com.example.user_service.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

// @Service marca esta clase como componente de lógica de negocio
// Aquí va toda la lógica: validaciones, transformaciones, reglas de negocio
@Service
// @RequiredArgsConstructor de Lombok inyecta automáticamente los campos final
// Es equivalente a escribir un constructor con @Autowired pero más limpio
@RequiredArgsConstructor
public class UsuarioService {

    // Spring inyecta esta dependencia automáticamente gracias a @RequiredArgsConstructor
    private final UsuarioRepository usuarioRepository;

    // Crea un nuevo usuario en la BD a partir del DTO de request
    public UsuarioResponse crearUsuario(UsuarioRequest request) {
        // Construye la entidad usando el patrón Builder (más legible que setters)
        Usuario usuario = Usuario.builder()
                .nombre(request.getNombre())
                .apellido(request.getApellido())
                .email(request.getEmail())
                .password(request.getPassword())
                .telefono(request.getTelefono())
                // Si el rol viene en el request lo usa, sino asigna CLIENTE por defecto
                .rol(request.getRol() != null ? Usuario.Rol.valueOf(request.getRol()) : Usuario.Rol.CLIENTE)
                .build();
        // save() inserta en la BD y retorna la entidad con el ID asignado
        return toResponse(usuarioRepository.save(usuario));
    }

    // Retorna todos los usuarios como lista de DTOs de response
    public List<UsuarioResponse> listarUsuarios() {
        // findAll() trae todos los registros, stream().map() convierte cada entidad a DTO
        return usuarioRepository.findAll().stream().map(this::toResponse).toList();
    }

    // Busca un usuario por ID, lanza NotFoundException si no existe
    public UsuarioResponse buscarPorId(Long id) {
        return toResponse(usuarioRepository.findById(id)
                // orElseThrow lanza la excepción si findById retorna vacío
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado con id: " + id)));
    }

    // Actualiza los datos de un usuario existente
    public UsuarioResponse actualizarUsuario(Long id, UsuarioRequest request) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado con id: " + id));
        // Actualiza solo los campos permitidos (no el rol ni el estado por seguridad)
        usuario.setNombre(request.getNombre());
        usuario.setApellido(request.getApellido());
        usuario.setEmail(request.getEmail());
        usuario.setTelefono(request.getTelefono());
        return toResponse(usuarioRepository.save(usuario));
    }

    // Elimina un usuario por ID
    public void eliminarUsuario(Long id) {
        // Verifica primero que existe antes de intentar eliminar
        if (!usuarioRepository.existsById(id))
            throw new NotFoundException("Usuario no encontrado con id: " + id);
        usuarioRepository.deleteById(id);
    }

    // Método privado auxiliar: convierte entidad Usuario → DTO UsuarioResponse
    // Se llama "toResponse" por convención para mantener consistencia
    private UsuarioResponse toResponse(Usuario u) {
        return UsuarioResponse.builder()
                .id(u.getId())
                .nombre(u.getNombre())
                .apellido(u.getApellido())
                .email(u.getEmail())
                .rol(u.getRol() != null ? u.getRol().name() : null)
                .telefono(u.getTelefono())
                .estado(u.getEstado() != null ? u.getEstado().name() : null)
                .fechaCreacion(u.getFechaCreacion())
                .build();
    }
}
