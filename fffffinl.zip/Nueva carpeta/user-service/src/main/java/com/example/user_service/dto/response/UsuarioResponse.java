package com.example.user_service.dto.response;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

// DTO de RESPONSE: representa los datos que la API devuelve al cliente
// No incluye la contraseña por seguridad (a diferencia de la entidad Usuario)
@Data
@Builder // permite construir el objeto con el patrón Builder: UsuarioResponse.builder().id(1L).nombre("...").build()
public class UsuarioResponse {
    private Long id;
    private String nombre;
    private String apellido;
    private String email;
    private String rol;
    private String telefono;
    private String estado;
    private LocalDateTime fechaCreacion;
    // NOTA: intencionalmente no se incluye "password" para no exponerla en la respuesta
}
