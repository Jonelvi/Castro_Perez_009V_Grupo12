package com.example.user_service.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

// @Entity indica que esta clase es una tabla en la base de datos
// Spring JPA se encarga de crear/gestionar la tabla automáticamente via Flyway
@Entity
@Table(name = "usuarios") // nombre de la tabla en MySQL
@Data           // Lombok: genera getters, setters, toString, equals automáticamente
@NoArgsConstructor  // Lombok: genera constructor vacío (requerido por JPA)
@AllArgsConstructor // Lombok: genera constructor con todos los campos
@Builder        // Lombok: permite usar el patrón Builder para crear objetos
public class Usuario {

    // @Id marca el campo como llave primaria
    // @GeneratedValue con IDENTITY hace que MySQL asigne el ID automáticamente (auto_increment)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // @Column(nullable = false) significa que este campo NO puede ser nulo en la BD
    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String apellido;

    // unique = true asegura que no puede haber dos usuarios con el mismo email
    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    // @Enumerated(EnumType.STRING) guarda el enum como texto en la BD (ej: "CLIENTE")
    // en vez de un número (0, 1, 2), lo que hace más legible la BD
    @Enumerated(EnumType.STRING)
    private Rol rol;

    private String telefono;

    @Enumerated(EnumType.STRING)
    private Estado estado;

    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;

    // @PrePersist se ejecuta automáticamente ANTES de guardar por primera vez en la BD
    // Sirve para asignar valores por defecto sin que el usuario tenga que enviarlos
    @PrePersist
    public void prePersist() {
        fechaCreacion = LocalDateTime.now(); // asigna la fecha y hora actual
        if (estado == null) estado = Estado.ACTIVO;   // estado por defecto
        if (rol == null) rol = Rol.CLIENTE;           // rol por defecto
    }

    // Enum de roles disponibles en el sistema
    public enum Rol { ADMIN, RECEPCIONISTA, CLIENTE }

    // Enum de estados posibles del usuario
    public enum Estado { ACTIVO, INACTIVO }
}
