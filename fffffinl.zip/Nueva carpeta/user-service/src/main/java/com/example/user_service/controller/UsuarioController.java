package com.example.user_service.controller;

import com.example.user_service.dto.request.UsuarioRequest;
import com.example.user_service.dto.response.UsuarioResponse;
import com.example.user_service.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// @RestController combina @Controller + @ResponseBody: indica que esta clase maneja
// peticiones HTTP y que los métodos retornan datos JSON directamente
@RestController
// @RequestMapping define el prefijo de todas las rutas de este controller
// Todas las rutas empezarán con /api/v1/usuarios
// El "v1" es una buena práctica para versionar la API
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    // @PostMapping → responde a peticiones HTTP POST en /api/v1/usuarios
    // @Valid activa las validaciones definidas en UsuarioRequest (@NotBlank, @Email, etc.)
    // @RequestBody convierte el JSON del body de la petición en un objeto UsuarioRequest
    // ResponseEntity<T> permite controlar el código HTTP de la respuesta
    @PostMapping
    public ResponseEntity<UsuarioResponse> crearUsuario(@Valid @RequestBody UsuarioRequest request) {
        // HttpStatus.CREATED = código 201, indica que se creó un recurso exitosamente
        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.crearUsuario(request));
    }

    // @GetMapping → responde a HTTP GET en /api/v1/usuarios
    // Retorna la lista completa de usuarios
    @GetMapping
    public ResponseEntity<List<UsuarioResponse>> listarUsuarios() {
        return ResponseEntity.ok(usuarioService.listarUsuarios()); // ok() = código 200
    }

    // @PathVariable extrae el {id} de la URL, ej: GET /api/v1/usuarios/5 → id=5
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioResponse> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(usuarioService.buscarPorId(id));
    }

    // @PutMapping → HTTP PUT para actualizar un recurso completo
    @PutMapping("/{id}")
    public ResponseEntity<UsuarioResponse> actualizarUsuario(
            @PathVariable Long id,
            @Valid @RequestBody UsuarioRequest request) {
        return ResponseEntity.ok(usuarioService.actualizarUsuario(id, request));
    }

    // @DeleteMapping → HTTP DELETE para eliminar un recurso
    // ResponseEntity<Void> indica que la respuesta no tiene body
    // noContent() = código 204, indica éxito sin contenido en la respuesta
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuario(id);
        return ResponseEntity.noContent().build();
    }
}
