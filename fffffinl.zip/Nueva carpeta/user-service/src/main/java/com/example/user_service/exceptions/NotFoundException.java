package com.example.user_service.exceptions;

// Excepción personalizada para cuando un recurso no existe en la BD
// Extiende RuntimeException para que no sea necesario declararla en cada método
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message); // pasa el mensaje al constructor de RuntimeException
    }
}
