package com.example.user_service.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

// DTO (Data Transfer Object) de REQUEST: representa los datos que el cliente envía al crear/actualizar
// Separa la entidad (tabla BD) de lo que recibe la API, evitando exponer campos internos
@Data // Lombok: genera getters y setters
public class UsuarioRequest {

    // @NotBlank valida que el campo no sea nulo ni vacío; si falla, devuelve el mensaje indicado
    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio")
    private String apellido;

    // @Email valida que el texto tenga formato de email válido (ejemplo@dominio.com)
    @Email(message = "Email inválido")
    @NotBlank(message = "El email es obligatorio")
    private String email;

    // @Size valida el largo mínimo/máximo del texto
    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String password;

    private String rol;      // opcional, si no viene se asigna CLIENTE por defecto
    private String telefono; // opcional
}
