package com.example.user_service.repository;

import com.example.user_service.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

// @Repository marca esta interfaz como componente de acceso a datos
// JpaRepository<Usuario, Long> provee métodos listos: save(), findAll(), findById(), deleteById(), etc.
// El primer parámetro es la entidad, el segundo es el tipo del ID
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Spring JPA genera la consulta SQL automáticamente interpretando el nombre del método:
    // "findByEmail" → SELECT * FROM usuarios WHERE email = ?
    Optional<Usuario> findByEmail(String email);

    // "existsByEmail" → SELECT COUNT(*) > 0 FROM usuarios WHERE email = ?
    // Retorna true si existe, false si no
    boolean existsByEmail(String email);
}
