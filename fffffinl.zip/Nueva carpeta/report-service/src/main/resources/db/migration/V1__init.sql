CREATE TABLE IF NOT EXISTS reportes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('OCUPACION','INGRESOS','RESERVAS','PAGOS') NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    datos JSON,
    fecha_generacion DATETIME
);
