package com.example.report_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List; import java.util.Map;

@FeignClient(name = "room-service", url = "${room-service.url}")
public interface HabitacionClient {
    @GetMapping("/api/v1/habitaciones")
    List<Map<String, Object>> listarHabitaciones();
}
