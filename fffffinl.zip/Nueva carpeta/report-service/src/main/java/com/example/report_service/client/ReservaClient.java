package com.example.report_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List; import java.util.Map;

@FeignClient(name = "reservation-service", url = "${reservation-service.url}")
public interface ReservaClient {
    @GetMapping("/api/v1/reservas")
    List<Map<String, Object>> listarReservas();
}
