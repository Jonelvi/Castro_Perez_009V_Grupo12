package com.example.report_service.dto.response;

import lombok.*; import java.util.Map;

@Data @Builder
public class ReporteResponse {
    private String tipo;
    private String fechaInicio;
    private String fechaFin;
    private Map<String, Object> datos;
}
