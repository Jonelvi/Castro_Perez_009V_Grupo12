package com.example.report_service.controller;

import com.example.report_service.client.HabitacionClient;
import com.example.report_service.client.PagoClient;
import com.example.report_service.client.ReservaClient;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.util.stream.Collectors;

// Controller de reportes: agrega datos de múltiples microservicios para generar estadísticas
// No tiene BD propia para reportes dinámicos: consulta en tiempo real a los otros servicios
// Usa OpenFeign para llamar a reservation-service, payment-service y room-service
@RestController
@RequestMapping("/api/v1/reportes")
@RequiredArgsConstructor
public class ReporteController {

    private final ReservaClient reservaClient;       // llama a reservation-service
    private final PagoClient pagoClient;             // llama a payment-service
    private final HabitacionClient habitacionClient; // llama a room-service

    // Resumen de reservas agrupadas por estado (PENDIENTE, CONFIRMADA, etc.)
    @GetMapping("/reservas/resumen")
    public ResponseEntity<Map<String, Object>> resumenReservas() {
        List<Map<String, Object>> reservas = reservaClient.listarReservas();

        // Collectors.groupingBy agrupa la lista por el campo "estado" y cuenta cuántos hay de cada uno
        Map<String, Long> porEstado = reservas.stream()
                .collect(Collectors.groupingBy(
                        r -> String.valueOf(r.get("estado")),
                        Collectors.counting()
                ));

        return ResponseEntity.ok(Map.of(
                "totalReservas", reservas.size(),
                "porEstado", porEstado
        ));
    }

    // Resumen de pagos: total de ingresos y distribución por método de pago
    @GetMapping("/pagos/resumen")
    public ResponseEntity<Map<String, Object>> resumenPagos() {
        List<Map<String, Object>> pagos = pagoClient.listarPagos();

        // Suma solo los pagos APROBADOS para calcular ingresos reales
        double totalIngresos = pagos.stream()
                .filter(p -> "APROBADO".equals(p.get("estado")))
                .mapToDouble(p -> {
                    Object monto = p.get("monto");
                    return monto instanceof Number n ? n.doubleValue() : 0.0;
                }).sum();

        // Agrupa por método de pago (EFECTIVO, TARJETA, etc.)
        Map<String, Long> porMetodo = pagos.stream()
                .collect(Collectors.groupingBy(
                        p -> String.valueOf(p.get("metodoPago")),
                        Collectors.counting()
                ));

        return ResponseEntity.ok(Map.of(
                "totalPagos", pagos.size(),
                "totalIngresos", totalIngresos,
                "porMetodoPago", porMetodo
        ));
    }

    // Porcentaje de ocupación de las habitaciones del hotel
    @GetMapping("/habitaciones/ocupacion")
    public ResponseEntity<Map<String, Object>> ocupacionHabitaciones() {
        List<Map<String, Object>> habitaciones = habitacionClient.listarHabitaciones();

        Map<String, Long> porEstado = habitaciones.stream()
                .collect(Collectors.groupingBy(
                        h -> String.valueOf(h.get("estado")),
                        Collectors.counting()
                ));

        long disponibles = porEstado.getOrDefault("DISPONIBLE", 0L);
        long ocupadas = porEstado.getOrDefault("OCUPADA", 0L);

        // Calcula el porcentaje de ocupación
        double porcentajeOcupacion = habitaciones.isEmpty() ? 0 :
                (double) ocupadas / habitaciones.size() * 100;

        return ResponseEntity.ok(Map.of(
                "totalHabitaciones", habitaciones.size(),
                "disponibles", disponibles,
                "ocupadas", ocupadas,
                "porEstado", porEstado,
                // Math.round con * 100.0 / 100.0 redondea a 2 decimales
                "porcentajeOcupacion", Math.round(porcentajeOcupacion * 100.0) / 100.0
        ));
    }

    // Reporte general con un resumen de todo el hotel
    @GetMapping("/general")
    public ResponseEntity<Map<String, Object>> reporteGeneral() {
        List<Map<String, Object>> reservas = reservaClient.listarReservas();
        List<Map<String, Object>> pagos = pagoClient.listarPagos();
        List<Map<String, Object>> habitaciones = habitacionClient.listarHabitaciones();

        double totalIngresos = pagos.stream()
                .filter(p -> "APROBADO".equals(p.get("estado")))
                .mapToDouble(p -> {
                    Object monto = p.get("monto");
                    return monto instanceof Number n ? n.doubleValue() : 0.0;
                }).sum();

        return ResponseEntity.ok(Map.of(
                "totalReservas", reservas.size(),
                "totalPagos", pagos.size(),
                "totalHabitaciones", habitaciones.size(),
                "totalIngresos", totalIngresos
        ));
    }

    // Filtra reservas por estado específico (ej: GET /reportes/reservas/por-estado/PENDIENTE)
    @GetMapping("/reservas/por-estado/{estado}")
    public ResponseEntity<Map<String, Object>> reservasPorEstado(@PathVariable String estado) {
        List<Map<String, Object>> reservas = reservaClient.listarReservas();

        // Filtra solo las reservas que coinciden con el estado indicado
        List<Map<String, Object>> filtradas = reservas.stream()
                .filter(r -> estado.equalsIgnoreCase(String.valueOf(r.get("estado"))))
                .toList();

        return ResponseEntity.ok(Map.of(
                "estado", estado,
                "total", filtradas.size(),
                "reservas", filtradas
        ));
    }
}
