package com.example.report_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List; import java.util.Map;

@FeignClient(name = "payment-service", url = "${payment-service.url}")
public interface PagoClient {
    @GetMapping("/api/v1/pagos")
    List<Map<String, Object>> listarPagos();
}
