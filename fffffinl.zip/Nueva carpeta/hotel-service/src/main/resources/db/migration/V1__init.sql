
CREATE TABLE IF NOT EXISTS hoteles (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    direccion VARCHAR(255) NOT NULL,
    ciudad VARCHAR(100),
    pais VARCHAR(80),
    telefono VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    estrellas TINYINT,
    descripcion TEXT
);
