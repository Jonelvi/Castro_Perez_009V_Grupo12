package com.example.hotel_service.exceptions;

// Excepción lanzada cuando no se encuentra un hotel en la BD
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) { super(message); }
}
