package com.example.hotel_service.repository;

import com.example.hotel_service.model.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Repositorio de Hotel: hereda métodos CRUD de JpaRepository
// No necesita métodos adicionales porque solo usamos los estándar
@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {}
