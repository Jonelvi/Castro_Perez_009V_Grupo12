package com.example.hotel_service.model;

import jakarta.persistence.*;
import lombok.*;

// Entidad que representa la tabla "hoteles" en la base de datos hotel_db
@Entity
@Table(name = "hoteles")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Hotel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String direccion;

    private String ciudad;
    private String pais;
    private String telefono;

    // unique = true: no puede haber dos hoteles con el mismo email
    @Column(unique = true)
    private String email;

    // Cantidad de estrellas del hotel (1 a 5)
    private Integer estrellas;

    // columnDefinition = "TEXT" permite textos largos (más de 255 caracteres)
    @Column(columnDefinition = "TEXT")
    private String descripcion;
}
