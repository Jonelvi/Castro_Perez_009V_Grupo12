package com.example.hotel_service.service;

import com.example.hotel_service.dto.request.HotelRequest;
import com.example.hotel_service.dto.response.HotelResponse;
import com.example.hotel_service.exceptions.NotFoundException;
import com.example.hotel_service.model.Hotel;
import com.example.hotel_service.repository.HotelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

// Capa de lógica de negocio para hoteles
@Service
@RequiredArgsConstructor
public class HotelService {

    private final HotelRepository hotelRepository;

    // Crea un nuevo hotel en la BD
    public HotelResponse crearHotel(HotelRequest req) {
        Hotel h = Hotel.builder()
                .nombre(req.getNombre())
                .direccion(req.getDireccion())
                .ciudad(req.getCiudad())
                .pais(req.getPais())
                .telefono(req.getTelefono())
                .email(req.getEmail())
                .estrellas(req.getEstrellas())
                .descripcion(req.getDescripcion())
                .build();
        return toResponse(hotelRepository.save(h));
    }

    // Retorna todos los hoteles
    public List<HotelResponse> listar() {
        return hotelRepository.findAll().stream().map(this::toResponse).toList();
    }

    // Busca hotel por ID o lanza 404
    public HotelResponse buscarPorId(Long id) {
        return toResponse(hotelRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Hotel no encontrado con id: " + id)));
    }

    // Actualiza todos los campos de un hotel existente
    public HotelResponse actualizar(Long id, HotelRequest req) {
        Hotel h = hotelRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Hotel no encontrado con id: " + id));
        h.setNombre(req.getNombre());
        h.setDireccion(req.getDireccion());
        h.setCiudad(req.getCiudad());
        h.setPais(req.getPais());
        h.setTelefono(req.getTelefono());
        h.setEmail(req.getEmail());
        h.setEstrellas(req.getEstrellas());
        h.setDescripcion(req.getDescripcion());
        return toResponse(hotelRepository.save(h));
    }

    // Elimina un hotel por ID
    public void eliminar(Long id) {
        if (!hotelRepository.existsById(id))
            throw new NotFoundException("Hotel no encontrado con id: " + id);
        hotelRepository.deleteById(id);
    }

    // Convierte entidad Hotel → DTO HotelResponse
    private HotelResponse toResponse(Hotel h) {
        return HotelResponse.builder()
                .id(h.getId()).nombre(h.getNombre()).direccion(h.getDireccion())
                .ciudad(h.getCiudad()).pais(h.getPais()).telefono(h.getTelefono())
                .email(h.getEmail()).estrellas(h.getEstrellas()).descripcion(h.getDescripcion())
                .build();
    }
}
