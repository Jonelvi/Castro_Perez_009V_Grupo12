package com.example.hotel_service.controller;

import com.example.hotel_service.dto.request.HotelRequest;
import com.example.hotel_service.dto.response.HotelResponse;
import com.example.hotel_service.service.HotelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// Controller de hoteles: expone los endpoints REST en /api/v1/hoteles
@RestController
@RequestMapping("/api/v1/hoteles")
@RequiredArgsConstructor
public class HotelController {

    private final HotelService hotelService;

    @PostMapping // POST /api/v1/hoteles → crea hotel
    public ResponseEntity<HotelResponse> crear(@Valid @RequestBody HotelRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(hotelService.crearHotel(req));
    }

    @GetMapping // GET /api/v1/hoteles → lista todos
    public ResponseEntity<List<HotelResponse>> listar() {
        return ResponseEntity.ok(hotelService.listar());
    }

    @GetMapping("/{id}") // GET /api/v1/hoteles/1 → busca por id
    public ResponseEntity<HotelResponse> buscar(@PathVariable Long id) {
        return ResponseEntity.ok(hotelService.buscarPorId(id));
    }

    @PutMapping("/{id}") // PUT /api/v1/hoteles/1 → actualiza
    public ResponseEntity<HotelResponse> actualizar(@PathVariable Long id, @Valid @RequestBody HotelRequest req) {
        return ResponseEntity.ok(hotelService.actualizar(id, req));
    }

    @DeleteMapping("/{id}") // DELETE /api/v1/hoteles/1 → elimina
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        hotelService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
