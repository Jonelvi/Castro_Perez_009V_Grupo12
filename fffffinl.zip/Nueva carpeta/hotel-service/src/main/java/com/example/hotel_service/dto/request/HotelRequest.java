package com.example.hotel_service.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

// DTO de entrada para crear o actualizar un hotel
@Data
public class HotelRequest {

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "La dirección es obligatoria")
    private String direccion;

    private String ciudad;
    private String pais;
    private String telefono;

    @Email // valida formato de email
    private String email;

    // @Min y @Max validan que las estrellas estén entre 1 y 5
    @Min(1) @Max(5)
    private Integer estrellas;

    private String descripcion;
}
