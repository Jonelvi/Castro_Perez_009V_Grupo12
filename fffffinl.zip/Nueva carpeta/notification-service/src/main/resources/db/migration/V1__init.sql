
CREATE TABLE IF NOT EXISTS notificaciones (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_usuario BIGINT NOT NULL,
    tipo ENUM('RESERVA','PAGO','CHECKIN','PROMOCION','SISTEMA'),
    titulo VARCHAR(150),
    mensaje TEXT,
    leida BOOLEAN DEFAULT FALSE,
    fecha_envio DATETIME
);
