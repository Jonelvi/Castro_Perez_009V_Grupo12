package com.example.notification_service.service;

import com.example.notification_service.dto.request.NotificacionRequest;
import com.example.notification_service.dto.response.NotificacionResponse;
import com.example.notification_service.exceptions.NotFoundException;
import com.example.notification_service.model.Notificacion;
import com.example.notification_service.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

// Gestiona notificaciones enviadas a los usuarios
// En este sistema las notificaciones se crean manualmente via API
// En producción se conectaría con Kafka para recibirlas de otros servicios automáticamente
@Service
@RequiredArgsConstructor
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;

    // Crea una nueva notificación para un usuario
    public NotificacionResponse crear(NotificacionRequest req) {
        Notificacion n = Notificacion.builder()
                .idUsuario(req.getIdUsuario())
                .tipo(Notificacion.Tipo.valueOf(req.getTipo()))
                .titulo(req.getTitulo())
                .mensaje(req.getMensaje())
                .build(); // leida = false por defecto (ver @PrePersist en el modelo)
        return toResponse(notificacionRepository.save(n));
    }

    // Lista todas las notificaciones de un usuario (leídas y no leídas)
    public List<NotificacionResponse> listarPorUsuario(Long idUsuario) {
        return notificacionRepository.findByIdUsuario(idUsuario).stream()
                .map(this::toResponse).toList();
    }

    // Lista solo las notificaciones NO leídas de un usuario
    // Útil para mostrar el contador de notificaciones pendientes
    public List<NotificacionResponse> listarNoLeidas(Long idUsuario) {
        return notificacionRepository.findByIdUsuarioAndLeida(idUsuario, false).stream()
                .map(this::toResponse).toList();
    }

    // Marca una notificación como leída
    public NotificacionResponse marcarLeida(Long id) {
        Notificacion n = notificacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Notificación no encontrada con id: " + id));
        n.setLeida(true); // cambia el estado de leída
        return toResponse(notificacionRepository.save(n));
    }

    public void eliminar(Long id) {
        if (!notificacionRepository.existsById(id))
            throw new NotFoundException("Notificación no encontrada con id: " + id);
        notificacionRepository.deleteById(id);
    }

    private NotificacionResponse toResponse(Notificacion n) {
        return NotificacionResponse.builder()
                .id(n.getId()).idUsuario(n.getIdUsuario())
                .tipo(n.getTipo() != null ? n.getTipo().name() : null)
                .titulo(n.getTitulo()).mensaje(n.getMensaje())
                .leida(n.getLeida()).fechaEnvio(n.getFechaEnvio())
                .build();
    }
}
