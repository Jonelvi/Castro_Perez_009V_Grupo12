package com.example.checkin_service.dto.response;
import lombok.*; import java.time.LocalDateTime; import java.util.Map;
@Data @Builder
public class CheckinResponse {
    private Long id;
    private Long idReserva;
    private Map<String,Object> reserva;
    private LocalDateTime fechaCheckin;
    private LocalDateTime fechaCheckout;
    private String estado;
    private Long idEmpleado;
    private String observaciones;
}
