package com.example.checkin_service.repository;
import com.example.checkin_service.model.Checkin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List; import java.util.Optional;
@Repository
public interface CheckinRepository extends JpaRepository<Checkin, Long> {
    Optional<Checkin> findByIdReservaAndEstado(Long idReserva, Checkin.Estado estado);
    List<Checkin> findByIdReserva(Long idReserva);
}
