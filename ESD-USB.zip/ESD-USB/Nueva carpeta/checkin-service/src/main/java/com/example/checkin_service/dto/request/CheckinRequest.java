package com.example.checkin_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class CheckinRequest {
    @NotNull private Long idReserva;
    private Long idEmpleado;
    private String observaciones;
}
