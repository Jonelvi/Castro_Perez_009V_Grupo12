package com.example.checkin_service.service;

import com.example.checkin_service.client.ReservaClient;
import com.example.checkin_service.dto.request.CheckinRequest;
import com.example.checkin_service.dto.response.CheckinResponse;
import com.example.checkin_service.exceptions.NotFoundException;
import com.example.checkin_service.model.Checkin;
import com.example.checkin_service.repository.CheckinRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime; import java.util.List; import java.util.Map;

@Service @RequiredArgsConstructor
public class CheckinService {
    private final CheckinRepository checkinRepository;
    private final ReservaClient reservaClient;

    public CheckinResponse realizarCheckin(CheckinRequest req) {
        reservaClient.obtenerReserva(req.getIdReserva());
        Checkin c = Checkin.builder().idReserva(req.getIdReserva())
                .fechaCheckin(LocalDateTime.now()).idEmpleado(req.getIdEmpleado())
                .observaciones(req.getObservaciones()).build();
        reservaClient.cambiarEstado(req.getIdReserva(), "CONFIRMADA");
        return toResponse(checkinRepository.save(c), null);
    }

    public CheckinResponse realizarCheckout(Long id) {
        Checkin c = checkinRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Checkin no encontrado con id: " + id));
        c.setFechaCheckout(LocalDateTime.now());
        c.setEstado(Checkin.Estado.COMPLETADO);
        reservaClient.cambiarEstado(c.getIdReserva(), "COMPLETADA");
        return toResponse(checkinRepository.save(c), null);
    }

    public List<CheckinResponse> listar() {
        return checkinRepository.findAll().stream().map(c -> toResponse(c, null)).toList();
    }

    public CheckinResponse buscarPorId(Long id) {
        Checkin c = checkinRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Checkin no encontrado con id: " + id));
        Map<String,Object> reserva = reservaClient.obtenerReserva(c.getIdReserva());
        return toResponse(c, reserva);
    }

    public List<CheckinResponse> listarPorReserva(Long idReserva) {
        return checkinRepository.findByIdReserva(idReserva).stream().map(c -> toResponse(c, null)).toList();
    }

    private CheckinResponse toResponse(Checkin c, Map<String,Object> reserva) {
        return CheckinResponse.builder().id(c.getId()).idReserva(c.getIdReserva()).reserva(reserva)
                .fechaCheckin(c.getFechaCheckin()).fechaCheckout(c.getFechaCheckout())
                .estado(c.getEstado() != null ? c.getEstado().name() : null)
                .idEmpleado(c.getIdEmpleado()).observaciones(c.getObservaciones()).build();
    }
}
