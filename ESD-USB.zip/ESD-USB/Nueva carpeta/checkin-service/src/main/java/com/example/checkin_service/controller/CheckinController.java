package com.example.checkin_service.controller;

import com.example.checkin_service.dto.request.CheckinRequest;
import com.example.checkin_service.dto.response.CheckinResponse;
import com.example.checkin_service.service.CheckinService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/v1/checkins") @RequiredArgsConstructor
public class CheckinController {
    private final CheckinService checkinService;

    @PostMapping
    public ResponseEntity<CheckinResponse> checkin(@Valid @RequestBody CheckinRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(checkinService.realizarCheckin(req));
    }
    @PatchMapping("/{id}/checkout")
    public ResponseEntity<CheckinResponse> checkout(@PathVariable Long id) { return ResponseEntity.ok(checkinService.realizarCheckout(id)); }
    @GetMapping
    public ResponseEntity<List<CheckinResponse>> listar() { return ResponseEntity.ok(checkinService.listar()); }
    @GetMapping("/{id}")
    public ResponseEntity<CheckinResponse> buscar(@PathVariable Long id) { return ResponseEntity.ok(checkinService.buscarPorId(id)); }
    @GetMapping("/reserva/{idReserva}")
    public ResponseEntity<List<CheckinResponse>> listarPorReserva(@PathVariable Long idReserva) { return ResponseEntity.ok(checkinService.listarPorReserva(idReserva)); }
}
