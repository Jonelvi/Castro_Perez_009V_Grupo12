package com.example.checkin_service.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "checkins") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Checkin {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "id_reserva", nullable = false) private Long idReserva;
    @Column(name = "fecha_checkin") private LocalDateTime fechaCheckin;
    @Column(name = "fecha_checkout") private LocalDateTime fechaCheckout;
    @Enumerated(EnumType.STRING) private Estado estado;
    @Column(name = "id_empleado") private Long idEmpleado;
    private String observaciones;
    @PrePersist public void prePersist() { if (estado == null) estado = Estado.ACTIVO; }
    public enum Estado { ACTIVO, COMPLETADO, CANCELADO }
}
