package com.example.auth_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class RegisterRequest {
    @NotBlank private String nombre;
    @Email @NotBlank private String email;
    @NotBlank @Size(min = 6) private String password;
    private String rol;
}
