package com.example.auth_service.service;

import com.example.auth_service.dto.request.LoginRequest;
import com.example.auth_service.dto.request.RegisterRequest;
import com.example.auth_service.dto.response.AuthResponse;
import com.example.auth_service.exceptions.NotFoundException;
import com.example.auth_service.model.Usuario;
import com.example.auth_service.repository.UsuarioRepository;
import com.example.auth_service.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service @RequiredArgsConstructor
public class AuthService {
    private final UsuarioRepository usuarioRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public AuthResponse register(RegisterRequest req) {
        if (usuarioRepository.existsByEmail(req.getEmail()))
            throw new RuntimeException("El email ya está registrado");
        Usuario u = Usuario.builder().nombre(req.getNombre()).email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .rol(req.getRol() != null ? Usuario.Rol.valueOf(req.getRol()) : Usuario.Rol.CLIENTE).build();
        usuarioRepository.save(u);
        String token = jwtUtil.generateToken(u.getEmail(), u.getRol().name());
        return AuthResponse.builder().token(token).tipo("Bearer").id(u.getId())
                .email(u.getEmail()).nombre(u.getNombre()).rol(u.getRol().name())
                .fechaExpiracion(jwtUtil.getExpiration(token)).build();
    }

    public AuthResponse login(LoginRequest req) {
        Usuario u = usuarioRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));
        if (!passwordEncoder.matches(req.getPassword(), u.getPassword()))
            throw new RuntimeException("Contraseña incorrecta");
        String token = jwtUtil.generateToken(u.getEmail(), u.getRol().name());
        return AuthResponse.builder().token(token).tipo("Bearer").id(u.getId())
                .email(u.getEmail()).nombre(u.getNombre()).rol(u.getRol().name())
                .fechaExpiracion(jwtUtil.getExpiration(token)).build();
    }

    public boolean validateToken(String token) { return jwtUtil.validateToken(token); }
}
