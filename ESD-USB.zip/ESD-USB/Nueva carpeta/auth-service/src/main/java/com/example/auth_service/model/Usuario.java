package com.example.auth_service.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "auth_usuarios") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, unique = true) private String email;
    @Column(nullable = false) private String password;
    @Enumerated(EnumType.STRING) private Rol rol;
    private String nombre;
    @Column(name = "fecha_creacion") private LocalDateTime fechaCreacion;
    @PrePersist public void prePersist() { fechaCreacion = LocalDateTime.now(); if (rol == null) rol = Rol.CLIENTE; }
    public enum Rol { ADMIN, RECEPCIONISTA, CLIENTE }
}
