package com.example.auth_service.dto.response;
import lombok.*; import java.time.LocalDateTime;
@Data @Builder
public class AuthResponse {
    private String token;
    private String tipo;
    private Long id;
    private String email;
    private String nombre;
    private String rol;
    private LocalDateTime fechaExpiracion;
}
