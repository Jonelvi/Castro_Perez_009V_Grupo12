package com.example.room_service.controller;

import com.example.room_service.dto.request.HabitacionRequest;
import com.example.room_service.dto.response.HabitacionResponse;
import com.example.room_service.service.HabitacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/v1/habitaciones") @RequiredArgsConstructor
public class HabitacionController {
    private final HabitacionService habitacionService;

    @PostMapping
    public ResponseEntity<HabitacionResponse> crear(@Valid @RequestBody HabitacionRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(habitacionService.crear(req));
    }
    @GetMapping
    public ResponseEntity<List<HabitacionResponse>> listar() { return ResponseEntity.ok(habitacionService.listar()); }
    @GetMapping("/{id}")
    public ResponseEntity<HabitacionResponse> buscar(@PathVariable Long id) { return ResponseEntity.ok(habitacionService.buscarPorId(id)); }
    @GetMapping("/hotel/{idHotel}")
    public ResponseEntity<List<HabitacionResponse>> listarPorHotel(@PathVariable Long idHotel) { return ResponseEntity.ok(habitacionService.listarPorHotel(idHotel)); }
    @PutMapping("/{id}")
    public ResponseEntity<HabitacionResponse> actualizar(@PathVariable Long id, @Valid @RequestBody HabitacionRequest req) { return ResponseEntity.ok(habitacionService.actualizar(id, req)); }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) { habitacionService.eliminar(id); return ResponseEntity.noContent().build(); }
}
