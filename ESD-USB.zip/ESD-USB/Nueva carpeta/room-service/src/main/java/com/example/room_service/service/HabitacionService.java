package com.example.room_service.service;

import com.example.room_service.client.HotelClient;
import com.example.room_service.dto.request.HabitacionRequest;
import com.example.room_service.dto.response.HabitacionResponse;
import com.example.room_service.exceptions.NotFoundException;
import com.example.room_service.model.Habitacion;
import com.example.room_service.repository.HabitacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service @RequiredArgsConstructor
public class HabitacionService {
    private final HabitacionRepository habitacionRepository;
    private final HotelClient hotelClient;

    public HabitacionResponse crear(HabitacionRequest req) {
        hotelClient.obtenerHotelPorId(req.getIdHotel());
        Habitacion h = Habitacion.builder().idHotel(req.getIdHotel()).numero(req.getNumero())
                .tipo(req.getTipo() != null ? Habitacion.Tipo.valueOf(req.getTipo()) : Habitacion.Tipo.SIMPLE)
                .precioNoche(req.getPrecioNoche()).capacidad(req.getCapacidad()).descripcion(req.getDescripcion()).build();
        return toResponse(habitacionRepository.save(h), null);
    }

    public List<HabitacionResponse> listar() {
        return habitacionRepository.findAll().stream().map(h -> toResponse(h, null)).toList();
    }

    public HabitacionResponse buscarPorId(Long id) {
        Habitacion h = habitacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Habitación no encontrada con id: " + id));
        Map<String,Object> hotel = hotelClient.obtenerHotelPorId(h.getIdHotel());
        return toResponse(h, hotel);
    }

    public List<HabitacionResponse> listarPorHotel(Long idHotel) {
        return habitacionRepository.findByIdHotel(idHotel).stream().map(h -> toResponse(h, null)).toList();
    }

    public HabitacionResponse actualizar(Long id, HabitacionRequest req) {
        Habitacion h = habitacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Habitación no encontrada con id: " + id));
        h.setNumero(req.getNumero()); h.setPrecioNoche(req.getPrecioNoche());
        h.setCapacidad(req.getCapacidad()); h.setDescripcion(req.getDescripcion());
        if (req.getTipo() != null) h.setTipo(Habitacion.Tipo.valueOf(req.getTipo()));
        return toResponse(habitacionRepository.save(h), null);
    }

    public void eliminar(Long id) {
        if (!habitacionRepository.existsById(id)) throw new NotFoundException("Habitación no encontrada con id: " + id);
        habitacionRepository.deleteById(id);
    }

    private HabitacionResponse toResponse(Habitacion h, Map<String,Object> hotel) {
        return HabitacionResponse.builder().id(h.getId()).idHotel(h.getIdHotel()).hotel(hotel)
                .numero(h.getNumero()).tipo(h.getTipo() != null ? h.getTipo().name() : null)
                .precioNoche(h.getPrecioNoche()).estado(h.getEstado() != null ? h.getEstado().name() : null)
                .capacidad(h.getCapacidad()).descripcion(h.getDescripcion()).build();
    }
}
