package com.example.room_service.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@FeignClient(name = "hotel-service", url = "${hotel-service.url}")
public interface HotelClient {
    @GetMapping("/api/v1/hoteles/{id}")
    Map<String, Object> obtenerHotelPorId(@PathVariable Long id);
}
