package com.example.room_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class HabitacionRequest {
    @NotNull private Long idHotel;
    @NotBlank private String numero;
    private String tipo;
    @NotNull @Positive private Double precioNoche;
    private Integer capacidad;
    private String descripcion;
}
