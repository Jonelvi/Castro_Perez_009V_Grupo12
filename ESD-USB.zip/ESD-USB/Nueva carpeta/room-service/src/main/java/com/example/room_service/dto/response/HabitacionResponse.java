package com.example.room_service.dto.response;
import lombok.*; import java.util.Map;
@Data @Builder
public class HabitacionResponse {
    private Long id;
    private Long idHotel;
    private Map<String,Object> hotel;
    private String numero;
    private String tipo;
    private Double precioNoche;
    private String estado;
    private Integer capacidad;
    private String descripcion;
}
