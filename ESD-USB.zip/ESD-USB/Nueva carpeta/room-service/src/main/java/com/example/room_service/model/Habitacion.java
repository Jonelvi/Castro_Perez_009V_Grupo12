package com.example.room_service.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name = "habitaciones") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Habitacion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "id_hotel", nullable = false) private Long idHotel;
    @Column(nullable = false) private String numero;
    @Enumerated(EnumType.STRING) private Tipo tipo;
    @Column(name = "precio_noche", nullable = false) private Double precioNoche;
    @Enumerated(EnumType.STRING) private Estado estado;
    private Integer capacidad;
    @Column(columnDefinition = "TEXT") private String descripcion;

    @PrePersist public void prePersist() { if (estado == null) estado = Estado.DISPONIBLE; }
    public enum Tipo { SIMPLE, DOBLE, SUITE, FAMILIAR }
    public enum Estado { DISPONIBLE, OCUPADA, MANTENIMIENTO }
}
