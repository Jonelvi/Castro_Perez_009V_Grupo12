package com.example.room_service.repository;
import com.example.room_service.model.Habitacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface HabitacionRepository extends JpaRepository<Habitacion, Long> {
    List<Habitacion> findByIdHotel(Long idHotel);
    List<Habitacion> findByEstado(Habitacion.Estado estado);
}
