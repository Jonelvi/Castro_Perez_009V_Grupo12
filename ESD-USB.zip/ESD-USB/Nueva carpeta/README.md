# Hotel Microservices

## Ports
| Servicio           | Puerto |
|--------------------|--------|
| eureka-server      | 8761   |
| api-gateway        | 8080   |
| user-service       | 8081   |
| hotel-service      | 8082   |
| room-service       | 8083   |
| reservation-service| 8084   |
| checkin-service    | 8085   |
| payment-service    | 8086   |
| notification-service| 8087  |
| auth-service       | 8088   |

## Inicio
1. `docker-compose up -d` (levanta todas las bases de datos)
2. Levantar eureka-server primero
3. Levantar api-gateway
4. Levantar el resto de servicios

## Eureka Dashboard
http://localhost:8761
