package com.example.notification_service.service;

import com.example.notification_service.dto.request.NotificacionRequest;
import com.example.notification_service.dto.response.NotificacionResponse;
import com.example.notification_service.exceptions.NotFoundException;
import com.example.notification_service.model.Notificacion;
import com.example.notification_service.repository.NotificacionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service @RequiredArgsConstructor
public class NotificacionService {
    private final NotificacionRepository notificacionRepository;

    public NotificacionResponse crear(NotificacionRequest req) {
        Notificacion n = Notificacion.builder().idUsuario(req.getIdUsuario())
                .tipo(Notificacion.Tipo.valueOf(req.getTipo()))
                .titulo(req.getTitulo()).mensaje(req.getMensaje()).build();
        return toResponse(notificacionRepository.save(n));
    }

    public List<NotificacionResponse> listarPorUsuario(Long idUsuario) {
        return notificacionRepository.findByIdUsuario(idUsuario).stream().map(this::toResponse).toList();
    }

    public List<NotificacionResponse> listarNoLeidas(Long idUsuario) {
        return notificacionRepository.findByIdUsuarioAndLeida(idUsuario, false).stream().map(this::toResponse).toList();
    }

    public NotificacionResponse marcarLeida(Long id) {
        Notificacion n = notificacionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Notificación no encontrada con id: " + id));
        n.setLeida(true);
        return toResponse(notificacionRepository.save(n));
    }

    public void eliminar(Long id) {
        if (!notificacionRepository.existsById(id)) throw new NotFoundException("Notificación no encontrada con id: " + id);
        notificacionRepository.deleteById(id);
    }

    private NotificacionResponse toResponse(Notificacion n) {
        return NotificacionResponse.builder().id(n.getId()).idUsuario(n.getIdUsuario())
                .tipo(n.getTipo() != null ? n.getTipo().name() : null)
                .titulo(n.getTitulo()).mensaje(n.getMensaje()).leida(n.getLeida()).fechaEnvio(n.getFechaEnvio()).build();
    }
}
