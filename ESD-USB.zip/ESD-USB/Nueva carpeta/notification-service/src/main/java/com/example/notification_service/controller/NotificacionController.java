package com.example.notification_service.controller;

import com.example.notification_service.dto.request.NotificacionRequest;
import com.example.notification_service.dto.response.NotificacionResponse;
import com.example.notification_service.service.NotificacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/v1/notificaciones") @RequiredArgsConstructor
public class NotificacionController {
    private final NotificacionService notificacionService;

    @PostMapping
    public ResponseEntity<NotificacionResponse> crear(@Valid @RequestBody NotificacionRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(notificacionService.crear(req));
    }
    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<NotificacionResponse>> listarPorUsuario(@PathVariable Long idUsuario) { return ResponseEntity.ok(notificacionService.listarPorUsuario(idUsuario)); }
    @GetMapping("/usuario/{idUsuario}/no-leidas")
    public ResponseEntity<List<NotificacionResponse>> listarNoLeidas(@PathVariable Long idUsuario) { return ResponseEntity.ok(notificacionService.listarNoLeidas(idUsuario)); }
    @PatchMapping("/{id}/leer")
    public ResponseEntity<NotificacionResponse> marcarLeida(@PathVariable Long id) { return ResponseEntity.ok(notificacionService.marcarLeida(id)); }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) { notificacionService.eliminar(id); return ResponseEntity.noContent().build(); }
}
