package com.example.notification_service.exceptions;
public class NotFoundException extends RuntimeException { public NotFoundException(String m) { super(m); } }
