package com.example.notification_service.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "notificaciones") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Notificacion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "id_usuario", nullable = false) private Long idUsuario;
    @Enumerated(EnumType.STRING) private Tipo tipo;
    private String titulo;
    @Column(columnDefinition = "TEXT") private String mensaje;
    private Boolean leida;
    @Column(name = "fecha_envio") private LocalDateTime fechaEnvio;
    @PrePersist public void prePersist() { fechaEnvio = LocalDateTime.now(); if (leida == null) leida = false; }
    public enum Tipo { RESERVA, PAGO, CHECKIN, PROMOCION, SISTEMA }
}
