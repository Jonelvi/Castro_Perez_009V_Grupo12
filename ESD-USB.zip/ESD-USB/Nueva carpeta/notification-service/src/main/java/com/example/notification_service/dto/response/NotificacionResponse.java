package com.example.notification_service.dto.response;
import lombok.*; import java.time.LocalDateTime;
@Data @Builder
public class NotificacionResponse {
    private Long id;
    private Long idUsuario;
    private String tipo;
    private String titulo;
    private String mensaje;
    private Boolean leida;
    private LocalDateTime fechaEnvio;
}
