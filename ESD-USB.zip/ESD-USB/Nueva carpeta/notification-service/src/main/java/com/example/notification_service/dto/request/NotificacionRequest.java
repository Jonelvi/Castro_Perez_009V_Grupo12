package com.example.notification_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class NotificacionRequest {
    @NotNull private Long idUsuario;
    @NotBlank private String tipo;
    @NotBlank private String titulo;
    @NotBlank private String mensaje;
}
