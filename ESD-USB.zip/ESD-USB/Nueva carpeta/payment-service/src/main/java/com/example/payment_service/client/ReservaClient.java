package com.example.payment_service.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@FeignClient(name = "reservation-service", url = "${reservation-service.url}")
public interface ReservaClient {
    @GetMapping("/api/v1/reservas/{id}") Map<String,Object> obtenerReserva(@PathVariable Long id);
}
