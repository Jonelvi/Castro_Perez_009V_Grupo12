package com.example.payment_service.exceptions;
public class NotFoundException extends RuntimeException { public NotFoundException(String m) { super(m); } }
