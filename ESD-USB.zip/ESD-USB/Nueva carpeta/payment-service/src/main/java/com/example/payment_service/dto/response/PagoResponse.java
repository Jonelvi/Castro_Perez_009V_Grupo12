package com.example.payment_service.dto.response;
import lombok.*; import java.time.LocalDateTime; import java.util.Map;
@Data @Builder
public class PagoResponse {
    private Long id;
    private Long idReserva;
    private Map<String,Object> reserva;
    private Double monto;
    private String metodoPago;
    private String estado;
    private LocalDateTime fechaPago;
    private String referencia;
}
