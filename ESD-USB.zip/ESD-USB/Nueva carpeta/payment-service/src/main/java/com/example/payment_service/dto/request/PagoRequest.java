package com.example.payment_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class PagoRequest {
    @NotNull private Long idReserva;
    @NotNull @Positive private Double monto;
    @NotBlank private String metodoPago;
    private String referencia;
}
