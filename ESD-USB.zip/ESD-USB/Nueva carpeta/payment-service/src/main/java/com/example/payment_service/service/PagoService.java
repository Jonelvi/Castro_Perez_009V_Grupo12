package com.example.payment_service.service;

import com.example.payment_service.client.ReservaClient;
import com.example.payment_service.dto.request.PagoRequest;
import com.example.payment_service.dto.response.PagoResponse;
import com.example.payment_service.exceptions.NotFoundException;
import com.example.payment_service.model.Pago;
import com.example.payment_service.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Map;

@Service @RequiredArgsConstructor
public class PagoService {
    private final PagoRepository pagoRepository;
    private final ReservaClient reservaClient;

    public PagoResponse crear(PagoRequest req) {
        reservaClient.obtenerReserva(req.getIdReserva());
        Pago p = Pago.builder().idReserva(req.getIdReserva()).monto(req.getMonto())
                .metodoPago(Pago.MetodoPago.valueOf(req.getMetodoPago()))
                .estado(Pago.Estado.APROBADO).referencia(req.getReferencia()).build();
        return toResponse(pagoRepository.save(p), null);
    }

    public List<PagoResponse> listar() {
        return pagoRepository.findAll().stream().map(p -> toResponse(p, null)).toList();
    }

    public PagoResponse buscarPorId(Long id) {
        Pago p = pagoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Pago no encontrado con id: " + id));
        Map<String,Object> reserva = reservaClient.obtenerReserva(p.getIdReserva());
        return toResponse(p, reserva);
    }

    public List<PagoResponse> listarPorReserva(Long idReserva) {
        return pagoRepository.findByIdReserva(idReserva).stream().map(p -> toResponse(p, null)).toList();
    }

    public PagoResponse cambiarEstado(Long id, String estado) {
        Pago p = pagoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Pago no encontrado con id: " + id));
        p.setEstado(Pago.Estado.valueOf(estado));
        return toResponse(pagoRepository.save(p), null);
    }

    private PagoResponse toResponse(Pago p, Map<String,Object> reserva) {
        return PagoResponse.builder().id(p.getId()).idReserva(p.getIdReserva()).reserva(reserva)
                .monto(p.getMonto()).metodoPago(p.getMetodoPago() != null ? p.getMetodoPago().name() : null)
                .estado(p.getEstado() != null ? p.getEstado().name() : null)
                .fechaPago(p.getFechaPago()).referencia(p.getReferencia()).build();
    }
}
