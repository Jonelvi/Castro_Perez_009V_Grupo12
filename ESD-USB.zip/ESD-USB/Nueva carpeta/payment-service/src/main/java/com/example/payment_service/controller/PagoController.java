package com.example.payment_service.controller;

import com.example.payment_service.dto.request.PagoRequest;
import com.example.payment_service.dto.response.PagoResponse;
import com.example.payment_service.service.PagoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/v1/pagos") @RequiredArgsConstructor
public class PagoController {
    private final PagoService pagoService;

    @PostMapping
    public ResponseEntity<PagoResponse> crear(@Valid @RequestBody PagoRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(pagoService.crear(req));
    }
    @GetMapping
    public ResponseEntity<List<PagoResponse>> listar() { return ResponseEntity.ok(pagoService.listar()); }
    @GetMapping("/{id}")
    public ResponseEntity<PagoResponse> buscar(@PathVariable Long id) { return ResponseEntity.ok(pagoService.buscarPorId(id)); }
    @GetMapping("/reserva/{idReserva}")
    public ResponseEntity<List<PagoResponse>> listarPorReserva(@PathVariable Long idReserva) { return ResponseEntity.ok(pagoService.listarPorReserva(idReserva)); }
    @PatchMapping("/{id}/estado")
    public ResponseEntity<PagoResponse> cambiarEstado(@PathVariable Long id, @RequestParam String estado) { return ResponseEntity.ok(pagoService.cambiarEstado(id, estado)); }
}
