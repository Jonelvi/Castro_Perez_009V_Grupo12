package com.example.payment_service.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name = "pagos") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Pago {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "id_reserva", nullable = false) private Long idReserva;
    @Column(nullable = false) private Double monto;
    @Enumerated(EnumType.STRING) @Column(name = "metodo_pago") private MetodoPago metodoPago;
    @Enumerated(EnumType.STRING) private Estado estado;
    @Column(name = "fecha_pago") private LocalDateTime fechaPago;
    private String referencia;
    @PrePersist public void prePersist() { fechaPago = LocalDateTime.now(); if (estado == null) estado = Estado.PENDIENTE; }
    public enum MetodoPago { EFECTIVO, TARJETA_CREDITO, TARJETA_DEBITO, TRANSFERENCIA }
    public enum Estado { PENDIENTE, APROBADO, RECHAZADO, REEMBOLSADO }
}
