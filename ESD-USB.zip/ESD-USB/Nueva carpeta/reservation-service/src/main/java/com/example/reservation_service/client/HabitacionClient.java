package com.example.reservation_service.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@FeignClient(name = "room-service", url = "${room-service.url}")
public interface HabitacionClient {
    @GetMapping("/api/v1/habitaciones/{id}") Map<String,Object> obtenerHabitacion(@PathVariable Long id);
}
