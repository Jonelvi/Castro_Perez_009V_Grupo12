package com.example.reservation_service;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
@SpringBootApplication @EnableFeignClients
public class ReservationServiceApplication {
    public static void main(String[] args) { SpringApplication.run(ReservationServiceApplication.class, args); }
}
