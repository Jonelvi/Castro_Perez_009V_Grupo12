package com.example.reservation_service.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate; import java.time.LocalDateTime;

@Entity @Table(name = "reservas") @Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Reserva {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "id_usuario", nullable = false) private Long idUsuario;
    @Column(name = "id_habitacion", nullable = false) private Long idHabitacion;
    @Column(name = "fecha_inicio", nullable = false) private LocalDate fechaInicio;
    @Column(name = "fecha_fin", nullable = false) private LocalDate fechaFin;
    @Enumerated(EnumType.STRING) private Estado estado;
    @Column(name = "precio_total") private Double precioTotal;
    private String notas;
    @Column(name = "fecha_creacion") private LocalDateTime fechaCreacion;
    @PrePersist public void prePersist() { fechaCreacion = LocalDateTime.now(); if (estado == null) estado = Estado.PENDIENTE; }
    public enum Estado { PENDIENTE, CONFIRMADA, CANCELADA, COMPLETADA }
}
