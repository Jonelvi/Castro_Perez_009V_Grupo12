package com.example.reservation_service.controller;

import com.example.reservation_service.dto.request.ReservaRequest;
import com.example.reservation_service.dto.response.ReservaResponse;
import com.example.reservation_service.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/v1/reservas") @RequiredArgsConstructor
public class ReservaController {
    private final ReservaService reservaService;

    @PostMapping
    public ResponseEntity<ReservaResponse> crear(@Valid @RequestBody ReservaRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reservaService.crear(req));
    }
    @GetMapping
    public ResponseEntity<List<ReservaResponse>> listar() { return ResponseEntity.ok(reservaService.listar()); }
    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponse> buscar(@PathVariable Long id) { return ResponseEntity.ok(reservaService.buscarPorId(id)); }
    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<ReservaResponse>> listarPorUsuario(@PathVariable Long idUsuario) { return ResponseEntity.ok(reservaService.listarPorUsuario(idUsuario)); }
    @PatchMapping("/{id}/estado")
    public ResponseEntity<ReservaResponse> cambiarEstado(@PathVariable Long id, @RequestParam String estado) { return ResponseEntity.ok(reservaService.cambiarEstado(id, estado)); }
}
