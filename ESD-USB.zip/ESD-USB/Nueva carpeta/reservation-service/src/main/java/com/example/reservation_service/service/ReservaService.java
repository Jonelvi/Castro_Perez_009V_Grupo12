package com.example.reservation_service.service;

import com.example.reservation_service.client.HabitacionClient;
import com.example.reservation_service.client.UsuarioClient;
import com.example.reservation_service.dto.request.ReservaRequest;
import com.example.reservation_service.dto.response.ReservaResponse;
import com.example.reservation_service.exceptions.NotFoundException;
import com.example.reservation_service.model.Reserva;
import com.example.reservation_service.repository.ReservaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List; import java.util.Map;

@Service @RequiredArgsConstructor
public class ReservaService {
    private final ReservaRepository reservaRepository;
    private final UsuarioClient usuarioClient;
    private final HabitacionClient habitacionClient;

    public ReservaResponse crear(ReservaRequest req) {
        usuarioClient.obtenerUsuario(req.getIdUsuario());
        Map<String,Object> habitacion = habitacionClient.obtenerHabitacion(req.getIdHabitacion());
        double precio = calcularPrecio(habitacion, req);
        Reserva r = Reserva.builder().idUsuario(req.getIdUsuario()).idHabitacion(req.getIdHabitacion())
                .fechaInicio(req.getFechaInicio()).fechaFin(req.getFechaFin())
                .notas(req.getNotas()).precioTotal(precio).build();
        return toResponse(reservaRepository.save(r), null, habitacion);
    }

    public List<ReservaResponse> listar() {
        return reservaRepository.findAll().stream().map(r -> toResponse(r, null, null)).toList();
    }

    public ReservaResponse buscarPorId(Long id) {
        Reserva r = reservaRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Reserva no encontrada con id: " + id));
        Map<String,Object> usuario = usuarioClient.obtenerUsuario(r.getIdUsuario());
        Map<String,Object> habitacion = habitacionClient.obtenerHabitacion(r.getIdHabitacion());
        return toResponse(r, usuario, habitacion);
    }

    public List<ReservaResponse> listarPorUsuario(Long idUsuario) {
        return reservaRepository.findByIdUsuario(idUsuario).stream().map(r -> toResponse(r, null, null)).toList();
    }

    public ReservaResponse cambiarEstado(Long id, String estado) {
        Reserva r = reservaRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Reserva no encontrada con id: " + id));
        r.setEstado(Reserva.Estado.valueOf(estado));
        return toResponse(reservaRepository.save(r), null, null);
    }

    private double calcularPrecio(Map<String,Object> habitacion, ReservaRequest req) {
        Object precioObj = habitacion.get("precioNoche");
        double precioNoche = precioObj instanceof Number n ? n.doubleValue() : 0;
        long dias = req.getFechaInicio().until(req.getFechaFin()).getDays();
        return precioNoche * dias;
    }

    private ReservaResponse toResponse(Reserva r, Map<String,Object> usuario, Map<String,Object> habitacion) {
        return ReservaResponse.builder().id(r.getId()).idUsuario(r.getIdUsuario()).usuario(usuario)
                .idHabitacion(r.getIdHabitacion()).habitacion(habitacion)
                .fechaInicio(r.getFechaInicio()).fechaFin(r.getFechaFin())
                .estado(r.getEstado() != null ? r.getEstado().name() : null)
                .precioTotal(r.getPrecioTotal()).notas(r.getNotas()).fechaCreacion(r.getFechaCreacion()).build();
    }
}
