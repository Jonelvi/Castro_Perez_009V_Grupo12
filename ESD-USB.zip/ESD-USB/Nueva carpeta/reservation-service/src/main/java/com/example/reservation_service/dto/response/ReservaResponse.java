package com.example.reservation_service.dto.response;
import lombok.*; import java.time.*; import java.util.Map;
@Data @Builder
public class ReservaResponse {
    private Long id;
    private Long idUsuario;
    private Map<String,Object> usuario;
    private Long idHabitacion;
    private Map<String,Object> habitacion;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String estado;
    private Double precioTotal;
    private String notas;
    private LocalDateTime fechaCreacion;
}
