package com.example.reservation_service.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@FeignClient(name = "user-service", url = "${user-service.url}")
public interface UsuarioClient {
    @GetMapping("/api/v1/usuarios/{id}") Map<String,Object> obtenerUsuario(@PathVariable Long id);
}
