package com.example.reservation_service.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
@Data
public class ReservaRequest {
    @NotNull private Long idUsuario;
    @NotNull private Long idHabitacion;
    @NotNull @FutureOrPresent private LocalDate fechaInicio;
    @NotNull @Future private LocalDate fechaFin;
    private String notas;
}
