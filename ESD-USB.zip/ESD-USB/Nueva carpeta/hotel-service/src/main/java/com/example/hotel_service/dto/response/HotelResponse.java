package com.example.hotel_service.dto.response;

import lombok.Builder; import lombok.Data;

@Data @Builder
public class HotelResponse {
    private Long id;
    private String nombre;
    private String direccion;
    private String ciudad;
    private String pais;
    private String telefono;
    private String email;
    private Integer estrellas;
    private String descripcion;
}
