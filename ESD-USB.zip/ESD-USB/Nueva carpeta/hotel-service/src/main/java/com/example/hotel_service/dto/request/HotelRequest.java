package com.example.hotel_service.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class HotelRequest {
    @NotBlank(message = "El nombre es obligatorio") private String nombre;
    @NotBlank(message = "La dirección es obligatoria") private String direccion;
    private String ciudad;
    private String pais;
    private String telefono;
    @Email private String email;
    @Min(1) @Max(5) private Integer estrellas;
    private String descripcion;
}
