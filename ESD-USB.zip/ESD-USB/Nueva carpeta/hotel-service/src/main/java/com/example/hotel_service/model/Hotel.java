package com.example.hotel_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "hoteles")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Hotel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private String nombre;
    @Column(nullable = false) private String direccion;
    private String ciudad;
    private String pais;
    private String telefono;
    @Column(unique = true) private String email;
    private Integer estrellas;
    @Column(columnDefinition = "TEXT") private String descripcion;
}
