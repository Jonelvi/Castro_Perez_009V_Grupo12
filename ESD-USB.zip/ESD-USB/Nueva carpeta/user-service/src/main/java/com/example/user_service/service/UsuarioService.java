package com.example.user_service.service;

import com.example.user_service.dto.request.UsuarioRequest;
import com.example.user_service.dto.response.UsuarioResponse;
import com.example.user_service.exceptions.NotFoundException;
import com.example.user_service.model.Usuario;
import com.example.user_service.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioResponse crearUsuario(UsuarioRequest request) {
        Usuario usuario = Usuario.builder()
                .nombre(request.getNombre())
                .apellido(request.getApellido())
                .email(request.getEmail())
                .password(request.getPassword())
                .telefono(request.getTelefono())
                .rol(request.getRol() != null ? Usuario.Rol.valueOf(request.getRol()) : Usuario.Rol.CLIENTE)
                .build();
        return toResponse(usuarioRepository.save(usuario));
    }

    public List<UsuarioResponse> listarUsuarios() {
        return usuarioRepository.findAll().stream().map(this::toResponse).toList();
    }

    public UsuarioResponse buscarPorId(Long id) {
        return toResponse(usuarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado con id: " + id)));
    }

    public UsuarioResponse actualizarUsuario(Long id, UsuarioRequest request) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado con id: " + id));
        usuario.setNombre(request.getNombre());
        usuario.setApellido(request.getApellido());
        usuario.setEmail(request.getEmail());
        usuario.setTelefono(request.getTelefono());
        return toResponse(usuarioRepository.save(usuario));
    }

    public void eliminarUsuario(Long id) {
        if (!usuarioRepository.existsById(id))
            throw new NotFoundException("Usuario no encontrado con id: " + id);
        usuarioRepository.deleteById(id);
    }

    private UsuarioResponse toResponse(Usuario u) {
        return UsuarioResponse.builder()
                .id(u.getId())
                .nombre(u.getNombre())
                .apellido(u.getApellido())
                .email(u.getEmail())
                .rol(u.getRol() != null ? u.getRol().name() : null)
                .telefono(u.getTelefono())
                .estado(u.getEstado() != null ? u.getEstado().name() : null)
                .fechaCreacion(u.getFechaCreacion())
                .build();
    }
}
